﻿using System;
using System.IO;
using System.Collections.Generic;

public class Process
{
    public string ProcessNumber { get; set; }
    public int ArrivalTime { get; set; }
    public int ExecutionDuration { get; set; }
    public string Trace { get; set; }

    public Process(string processNumber, int arrivalTime, int executionDuration)
    {
        this.ProcessNumber = processNumber;
        this.ArrivalTime = arrivalTime;
        this.ExecutionDuration = executionDuration;
        this.Trace = "";
    }
}

class Program
{
    static void Main(string[] args)
    {
        string inputFile = args.Length > 0 ? args[0] : "jobs.txt";
        string outputFile = args.Length > 1 ? args[1] : "traceout.txt";

        List<Process> readyQueue = ReadInputFile(inputFile);

        List<Queue<Process>> queues = new List<Queue<Process>>();
        for (int i = 0; i <= 5; i++)
            queues.Add(new Queue<Process>());

        int time = 0;
        bool has_run = false;

        while (true)
        {
            has_run = false;

            while (readyQueue.Count > 0 && readyQueue[0].ArrivalTime <= time)
            {
                queues[0].Enqueue(readyQueue[0]);
                readyQueue.RemoveAt(0);
            }

            for (int N = 1; N <= 5; N++)
            {
                if (queues[N].Count > 0)
                {
                    Process process = queues[N].Dequeue();

                    int quantum = GetQuantum(N);
                    int runTime = Math.Min(quantum, process.ExecutionDuration);

                    process.ExecutionDuration -= runTime;
                    time += runTime;
                    has_run = true;

                    process.Trace += new String(process.ProcessNumber[0], runTime);

                    if (process.ExecutionDuration > 0)
                    {
                        if (N == 5)
                            queues[N].Enqueue(process);
                        else
                            queues[N + 1].Enqueue(process);
                    }

                    break;
                }
            }

            if (!has_run)
            {
                time += 1;

                if (readyQueue.Count == 0 && !AreThereProcessesInQueues(queues))
                    break;
            }
        }

        WriteOutputFile(outputFile, queues);
    }

    static List<Process> ReadInputFile(string filePath)
    {
        List<Process> readyQueue = new List<Process>();

        using (StreamReader sr = new StreamReader(filePath))
        {
            string line;

            while ((line = sr.ReadLine()) != null)
            {
                string[] attributes = line.Split('~');
                Process process = new Process(attributes[0], int.Parse(attributes[1]), int.Parse(attributes[2]));
                readyQueue.Add(process);
            }
        }

        readyQueue.Sort((p1, p2) => p1.ArrivalTime.CompareTo(p2.ArrivalTime));

        return readyQueue;
    }

    static int GetQuantum(int level)
    {
        int[] quanta = { 0, 1, 2, 4, 6, 8 };
        return quanta[level];
    }

    static bool AreThereProcessesInQueues(List<Queue<Process>> queues)
    {
        foreach (Queue<Process> queue in queues)
        {
            if (queue.Count > 0)
            {
                return true;
            }
        }

        return false;
    }

    static void WriteOutputFile(string filePath, List<Queue<Process>> queues)
    {
        using (StreamWriter sw = new StreamWriter(filePath))
        {
            if (sw != null)
            {
                foreach (Queue<Process> queue in queues)
                {
                    foreach (Process process in queue)
                    {
                        sw.WriteLine($"Process: {process.ProcessNumber}, Trace: {process.Trace}");
                    }
                }
            }
        }
    }
}
