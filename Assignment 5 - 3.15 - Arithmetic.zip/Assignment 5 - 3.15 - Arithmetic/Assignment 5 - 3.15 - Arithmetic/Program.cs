﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Please enter the first integer: ");
        int firstNum = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Please enter the second integer: ");
        int secondNum = Convert.ToInt32(Console.ReadLine());

        int sum = firstNum + secondNum;
        int product = firstNum * secondNum;
        int difference = firstNum - secondNum;
        int quotient = firstNum / secondNum;

        Console.WriteLine("Sum is: " + sum);
        Console.WriteLine("Product is: " + product);
        Console.WriteLine("Difference is: " + difference);
        Console.WriteLine("Quotient is: " + quotient);
    }
}


