﻿using System;

namespace ParkingGarage
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the number of customers: ");
            int numCustomers = int.Parse(Console.ReadLine());
            double totalCharges = 0;

            for (int i = 1; i <= numCustomers; i++)
            {
                Console.Write($"Enter hours parked for customer {i}: ");
                double hoursParked = double.Parse(Console.ReadLine());
                double currentCharge = CalculateCharges(hoursParked);

                Console.WriteLine($"Charge for customer {i}: ${currentCharge:F2}");
                totalCharges += currentCharge;
            }

            Console.WriteLine($"Total charges for yesterday: ${totalCharges:F2}");
        }

        static double CalculateCharges(double hours)
        {
            const double minFee = 2.0;
            const double hourlyFee = 0.5;
            const double maxFee = 10.0;

            if (hours <= 3)
            {
                return minFee;
            }
            else
            {
                double extraHours = Math.Ceiling(hours - 3);
                double charge = minFee + (extraHours * hourlyFee);
                return charge > maxFee ? maxFee : charge;
            }
        }
    }
}
