﻿using System;
using System.Reflection.Emit;
using System.Windows.Forms;

public class LoginPasswordUserControl : UserControl
{
    private Label loginLabel;
    private TextBox loginTextBox;
    private Label passwordLabel;
    private TextBox passwordTextBox;

    public LoginPasswordUserControl()
    {
        InitializeComponent();
    }

    private void InitializeComponent()
    {
        // Initialize components and set properties
        loginLabel = new Label();
        loginTextBox = new TextBox();
        passwordLabel = new Label();
        passwordTextBox = new TextBox();

        // Set properties for loginLabel
        loginLabel.Text = "Login:";
        loginLabel.Location = new System.Drawing.Point(10, 10);
        loginLabel.Size = new System.Drawing.Size(40, 20);

        // Set properties for loginTextBox
        loginTextBox.Location = new System.Drawing.Point(60, 10);
        loginTextBox.Size = new System.Drawing.Size(100, 20);

        // Set properties for passwordLabel
        passwordLabel.Text = "Password:";
        passwordLabel.Location = new System.Drawing.Point(10, 40);
        passwordLabel.Size = new System.Drawing.Size(60, 20);

        // Set properties for passwordTextBox
        passwordTextBox.Location = new System.Drawing.Point(80, 40);
        passwordTextBox.Size = new System.Drawing.Size(100, 20);
        passwordTextBox.PasswordChar = '*';

        // Add controls to the UserControl
        this.Controls.Add(loginLabel);
        this.Controls.Add(loginTextBox);
        this.Controls.Add(passwordLabel);
        this.Controls.Add(passwordTextBox);
    }

    public string Login
    {
        get { return loginTextBox.Text; }
    }

    public string Password
    {
        get { return passwordTextBox.Text; }
    }
}
