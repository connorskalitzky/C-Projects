﻿using System;

namespace HealthProfileApp
{
    class HealthProfile
    {
        private string firstName;
        private string lastName;
        private string gender;
        private int monthOfBirth;
        private int dayOfBirth;
        private int yearOfBirth;
        private double height;
        private double weight;

        public HealthProfile(string firstName, string lastName, string gender, int monthOfBirth, int dayOfBirth, int yearOfBirth, double height, double weight)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.gender = gender;
            this.monthOfBirth = monthOfBirth;
            this.dayOfBirth = dayOfBirth;
            this.yearOfBirth = yearOfBirth;
            this.height = height;
            this.weight = weight;
        }

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public int MonthOfBirth
        {
            get { return monthOfBirth; }
            set { monthOfBirth = value; }
        }

        public int DayOfBirth
        {
            get { return dayOfBirth; }
            set { dayOfBirth = value; }
        }

        public int YearOfBirth
        {
            get { return yearOfBirth; }
            set { yearOfBirth = value; }
        }

        public double Height
        {
            get { return height; }
            set { height = value; }
        }

        public double Weight
        {
            get { return weight; }
            set { weight = value; }
        }

        public int GetAge()
        {
            int currentYear = DateTime.Now.Year;
            return currentYear - yearOfBirth;
        }

        public int GetMaxHeartRate()
        {
            return 220 - GetAge();
        }

        public string GetTargetHeartRateRange()
        {
            double lowerBound = GetMaxHeartRate() * 0.5;
            double upperBound = GetMaxHeartRate() * 0.85;
            return lowerBound + " - " + upperBound;
        }

        public double GetBMI()
        {
            return weight * 703 / Math.Pow(height, 2);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your first name: ");
            string firstName = Console.ReadLine();

            Console.WriteLine("Enter your last name: ");
            string lastName = Console.ReadLine();

            Console.WriteLine("Enter your gender (M/F): ");
            string gender = Console.ReadLine();

            Console.WriteLine("Enter your month of birth: ");
            int monthOfBirth = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter your day of birth: ");
        }
    }
}
