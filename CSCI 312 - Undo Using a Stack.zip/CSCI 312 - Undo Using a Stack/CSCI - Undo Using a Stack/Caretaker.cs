﻿using System;
namespace CSCI___Undo_Using_a_Stack
{
    public class Caretaker
    {
        private Stack<Memento> _mementos = new Stack<Memento>();

        public void AddMemento(Memento memento)
        {
            _mementos.Push(memento);
        }

        public Memento GetMemento()
        {
            if (_mementos.Count > 0)
                return _mementos.Pop();
            else
                return null; // Return null if there are no mementos left
        }
    }
}
