﻿using System;
using System.Globalization;

namespace CSCI___Undo_Using_a_Stack
{
    class Program
    {
        public static void Main(string[] args)
        {
            var calculator = new Calculator();
            var caretaker = new Caretaker();

            var cultureInfo = CultureInfo.CurrentCulture;

            var messages = new Dictionary<string, Dictionary<string, string>>
            {
                ["en"] = new Dictionary<string, string>
                {
                    ["enter"] = "Enter a command or calculation: ",
                    ["invalid_input"] = "Invalid input. Please enter a calculation in the format 'number operation number', or one of the commands UNDO, CLEAR, EXIT.",
                    ["invalid_operation"] = "Invalid operation. Please enter one of the following operations: +, -, *, /.",
                    ["cannot_divide"] = "Cannot divide by zero",
                    ["result"] = "Result: ",
                    ["running_total"] = "Running total: "
                },
                ["es"] = new Dictionary<string, string>
                {
                    ["enter"] = "Ingrese un comando o cálculo: ",
                    ["invalid_input"] = "Entrada no válida. Ingrese un cálculo en el formato 'número de operación numérica', o uno de los comandos DESHACER, BORRAR, SALIR.",
                    ["invalid_operation"] = "Operación no válida. Ingrese una de las siguientes operaciones: +, -, *, /.",
                    ["cannot_divide"] = "No se puede dividir por cero",
                    ["resultado"] = "Resultado: ",
                    ["running_total"] = "Total acumulado: "
                },
                ["zh"] = new Dictionary<string, string>
                {
                    ["enter"] = "输入命令或计算：",
                    ["invalid_input"] = "无效输入。请以'number operation number'格式输入计算，或UNDO、CLEAR、EXIT命令之一。",
                    ["invalid_operation"] = "无效操作。请输入以下操作之一：+、-、*、/。",
                    ["cannot_divide"] = "不能除以零",
                    ["结果"] = "结果：",
                    ["running_total"] = "运行总计："
                }
            };
            var currentMessages = messages.ContainsKey(cultureInfo.TwoLetterISOLanguageName)
                ? messages[cultureInfo.TwoLetterISOLanguageName]
                : messages["en"];

            while (true)
            {
                Console.Write(currentMessages["enter"]);
                var input = Console.ReadLine().Trim();

                if (input.ToUpper() == "EXIT")
                    break;

                if (input.ToUpper() == "UNDO")
                {
                    calculator.RestoreMemento(caretaker.GetMemento());
                    Console.WriteLine(currentMessages["running_total"] + calculator.GetRunningTotal());
                    continue;
                }

                if (input.ToUpper() == "CLEAR")
                {
                    calculator = new Calculator();
                    caretaker = new Caretaker();
                    Console.WriteLine(currentMessages["running_total"] + "0");
                    continue;
                }

                var parts = input.Split();
                if (parts.Length != 3)
                {
                    Console.WriteLine(currentMessages["invalid_input"]);
                    continue;
                }

                var a = double.Parse(parts[0]);
                var op = parts[1];
                var b = double.Parse(parts[2]);

                double result;
                switch (op)
                {
                    case "+":
                        result = calculator.Add(a, b);
                        break;
                    case "-":
                        result = calculator.Subtract(a, b);
                        break;
                    case "*":
                        result = calculator.Multiply(a, b);
                        break;
                    case "/":
                        try
                        {
                            result = calculator.Divide(a, b);
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(currentMessages["cannot_divide"]);
                            continue;
                        }
                        break;
                    default:
                        Console.WriteLine(currentMessages["invalid_operation"]);
                        continue;
                }

                caretaker.AddMemento(calculator.SaveMemento());
                Console.WriteLine(currentMessages["result"] + result);
                Console.WriteLine(currentMessages["running_total"] + calculator.GetRunningTotal());
            }
        }
    }
}