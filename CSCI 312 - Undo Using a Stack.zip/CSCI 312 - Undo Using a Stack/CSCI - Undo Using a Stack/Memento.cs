﻿using System;
namespace CSCI___Undo_Using_a_Stack
{
    public class Memento
    {
        public double RunningTotal { get; private set; }

        public Memento(double runningTotal)
        {
            RunningTotal = runningTotal;
        }
    }
}

