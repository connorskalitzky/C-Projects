﻿using System;
using System.Runtime.ConstrainedExecution;

namespace CSCI___Undo_Using_a_Stack
{
    public class Calculator
    {
        private double _runningTotal = 0;

        public double Add(double a, double b)
        {
            _runningTotal += a + b;
            return a + b;
        }

        public double Subtract(double a, double b)
        {
            _runningTotal += a - b;
            return a - b;
        }

        public double Multiply(double a, double b)
        {
            _runningTotal += a * b;
            return a * b;
        }

        public double Divide(double a, double b)
        {
            if (b == 0)
                throw new ArgumentException("Cannot divide by zero");
            _runningTotal += a / b;
            return a / b;
        }

        public double GetRunningTotal()
        {
            return _runningTotal;
        }

        public Memento SaveMemento()
        {
            return new Memento(_runningTotal);
        }

        public void RestoreMemento(Memento memento)
        {
            if (memento != null)
                _runningTotal = memento.RunningTotal;
        }
    }
}
