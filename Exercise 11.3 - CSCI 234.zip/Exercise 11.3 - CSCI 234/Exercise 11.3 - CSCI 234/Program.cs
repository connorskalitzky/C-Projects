﻿using System;

public class CommissionEmployee
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string SocialSecurityNumber { get; set; }
    public decimal GrossSales { get; set; }
    public decimal CommissionRate { get; set; }

    public CommissionEmployee(string firstName, string lastName, string ssn)
    {
        FirstName = firstName;
        LastName = lastName;
        SocialSecurityNumber = ssn;
    }

    public decimal Earnings()
    {
        // Some logic for Earnings (this is just an example)
        return GrossSales * CommissionRate;
    }

    public override string ToString()
    {
        return $"{FirstName} {LastName} - SSN: {SocialSecurityNumber}";
    }
}

public class BasePlusCommissionEmployee
{
    private CommissionEmployee _commissionEmployee;
    private decimal _baseSalary;

    public BasePlusCommissionEmployee(string firstName, string lastName,
                                      string socialSecurityNumber, decimal grossSales,
                                      decimal commissionRate, decimal baseSalary)
    {
        _commissionEmployee = new CommissionEmployee(firstName, lastName, socialSecurityNumber)
        {
            GrossSales = grossSales,
            CommissionRate = commissionRate
        };

        BaseSalary = baseSalary; // This sets the base salary with validation
    }

    public decimal BaseSalary
    {
        get { return _baseSalary; }
        set
        {
            if (value < 0)
                throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(BaseSalary)} must be >= 0");
            _baseSalary = value;
        }
    }

    public decimal Earnings()
    {
        return BaseSalary + _commissionEmployee.Earnings();
    }

    public override string ToString()
    {
        return $"Base-Salaried {_commissionEmployee.ToString()}\nBase Salary: {BaseSalary:C}";
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        // Example of how you can instantiate and use the classes
        BasePlusCommissionEmployee employee = new BasePlusCommissionEmployee("John", "Doe", "123-45-6789", 1000m, 0.1m, 500m);
        Console.WriteLine(employee.ToString());
    }
}
