﻿using System;

class Number
{
    static void Main()
    {
        Console.WriteLine("Part (a): 1 2 3 4");
        Console.WriteLine();
        Console.Write("Part (b): 1 ");
        Console.Write("2 ");
        Console.Write("3 ");
        Console.Write("4");
        Console.WriteLine();
        Console.WriteLine("Part (c): {0} {1} {2} {3}", 1, 2, 3, 4);
    }
}