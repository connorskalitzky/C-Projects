﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;

public class GradeFileProcessor
{
    public void SerializeStudentGrades(string filePath, List<StudentGrade> studentGrades)
    {
        var options = new JsonSerializerOptions { WriteIndented = true };
        string jsonString = JsonSerializer.Serialize(studentGrades, options);
        File.WriteAllText(filePath, jsonString);
    }

    public List<StudentGrade> DeserializeStudentGrades(string filePath)
    {
        string jsonString = File.ReadAllText(filePath);
        return JsonSerializer.Deserialize<List<StudentGrade>>(jsonString);
    }
}
