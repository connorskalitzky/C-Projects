﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        var fileProcessor = new GradeFileProcessor();
        Console.WriteLine("Welcome to the Student Grade Serialization Program!");

        while (true)
        {
            Console.WriteLine("\nSelect an option:");
            Console.WriteLine("1. Serialize Sample Data");
            Console.WriteLine("2. Deserialize and Display Data");
            Console.WriteLine("3. Exit");

            var input = Console.ReadLine();
            switch (input)
            {
                case "1":
                    SerializeSampleData(fileProcessor);
                    break;
                case "2":
                    DeserializeAndDisplayData(fileProcessor);
                    break;
                case "3":
                    return;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }

    private static void SerializeSampleData(GradeFileProcessor fileProcessor)
    {
        var sampleData = new List<StudentGrade>
        {
            new StudentGrade { LastName = "Jones", FirstName = "Bob", ID = 1, ClassTaken = "Introduction to Computer Science", Grade = "A-" },
            // Add other sample data here
        };

        Console.Write("Enter the filename to save: ");
        string filename = Console.ReadLine() ?? string.Empty;

        fileProcessor.SerializeStudentGrades(filename, sampleData);
        Console.WriteLine("Data serialized successfully.");
    }

    private static void DeserializeAndDisplayData(GradeFileProcessor fileProcessor)
    {
        Console.Write("Enter the filename to load: ");
        string filename = Console.ReadLine() ?? string.Empty;

        if (File.Exists(filename))
        {
            try
            {
                var studentGrades = fileProcessor.DeserializeStudentGrades(filename);
                foreach (var grade in studentGrades)
                {
                    Console.WriteLine(grade);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading file: " + ex.Message);
            }
        }
        else
        {
            Console.WriteLine("File not found.");
        }
    }
}
