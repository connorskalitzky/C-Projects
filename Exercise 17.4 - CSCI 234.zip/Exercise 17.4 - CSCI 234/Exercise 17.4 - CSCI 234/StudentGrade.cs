﻿using System;

[Serializable]
public class StudentGrade
{
    public string LastName { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public int ID { get; set; }
    public string ClassTaken { get; set; } = string.Empty;
    public string Grade { get; set; } = string.Empty;

    public override string ToString()
    {
        return $"{LastName}, {FirstName}: {ID} {ClassTaken} {Grade}";
    }
}
