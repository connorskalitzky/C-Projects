﻿using System;
using System.Linq;

class DeckOfCardsTests
{
    static void Main()
    {
        var myDeckOfCards = new DeckOfCards();
        myDeckOfCards.Shuffle();

        Card[] pokerHand = new Card[5];

        for (var i = 0; i < 5; ++i)
        {
            pokerHand[i] = myDeckOfCards.DealCard();
            Console.WriteLine(pokerHand[i]);
        }

        Console.WriteLine(myDeckOfCards.EvaluateHand(pokerHand));
    }
}

class Card
{
    public string Face { get; }
    public string Suit { get; }

    public Card(string face, string suit)
    {
        Face = face;
        Suit = suit;
    }

    public override string ToString()
    {
        return $"{Face} of {Suit}";
    }
}

class DeckOfCards
{
    private static Random randomNumbers = new Random();
    private const int NumberOfCards = 52;
    private Card[] deck = new Card[NumberOfCards];
    private int currentCard = 0;

    public DeckOfCards()
    {
        string[] faces = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King" };
        string[] suits = { "Hearts", "Diamonds", "Clubs", "Spades" };

        for (var count = 0; count < deck.Length; ++count)
        {
            deck[count] = new Card(faces[count % 13], suits[count / 13]);
        }
    }

    public void Shuffle()
    {
        currentCard = 0;

        for (var first = 0; first < deck.Length; ++first)
        {
            var second = randomNumbers.Next(NumberOfCards);

            Card temp = deck[first];
            deck[first] = deck[second];
            deck[second] = temp;
        }
    }

    public Card DealCard()
    {
        if (currentCard < deck.Length)
        {
            return deck[currentCard++];
        }
        else
        {
            return null;
        }
    }

    public string EvaluateHand(Card[] hand)
    {
        if (IsFourOfAKind(hand))
            return "Four of a kind!";
        if (IsFullHouse(hand))
            return "Full house!";
        if (IsFlush(hand))
            return "Flush!";
        if (IsStraight(hand))
            return "Straight!";
        if (IsThreeOfAKind(hand))
            return "Three of a kind!";
        if (IsTwoPair(hand))
            return "Two pair!";
        if (IsPair(hand))
            return "One pair!";
        return "High card!";
    }

    private bool IsPair(Card[] hand)
    {
        var groups = hand.GroupBy(card => card.Face).ToList();
        return groups.Count(group => group.Count() == 2) == 1;
    }

    private bool IsTwoPair(Card[] hand)
    {
        var groups = hand.GroupBy(card => card.Face).ToList();
        return groups.Count(group => group.Count() == 2) == 2;
    }

    private bool IsThreeOfAKind(Card[] hand)
    {
        var groups = hand.GroupBy(card => card.Face).ToList();
        return groups.Any(group => group.Count() == 3);
    }

    private bool IsFourOfAKind(Card[] hand)
    {
        var groups = hand.GroupBy(card => card.Face).ToList();
        return groups.Any(group => group.Count() == 4);
    }

    private bool IsFlush(Card[] hand)
    {
        var suits = hand.GroupBy(card => card.Suit).ToList();
        return suits.Count == 1;
    }

    private bool IsStraight(Card[] hand)
    {
        int[] faceValues = new int[hand.Length];
        string[] faces = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King" };

        for (int i = 0; i < hand.Length; i++)
        {
            faceValues[i] = Array.IndexOf(faces, hand[i].Face) + 1;
        }

        Array.Sort(faceValues);

        // Check for a straight with an Ace as the high card (10-J-Q-K-A)
        if (faceValues[0] == 1 && faceValues[1] == 10 && faceValues[2] == 11 && faceValues[3] == 12 && faceValues[4] == 13)
        {
            return true;
        }

        for (int i = 1; i < faceValues.Length; i++)
        {
            if (faceValues[i] != faceValues[i - 1] + 1)
            {
                return false;
            }
        }

        return true;
    }

    private bool IsFullHouse(Card[] hand)
    {
        var groups = hand.GroupBy(card => card.Face).ToList();
        return groups.Count(group => group.Count() == 3) == 1 && groups.Count(group => group.Count() == 2) == 1;
    }
}