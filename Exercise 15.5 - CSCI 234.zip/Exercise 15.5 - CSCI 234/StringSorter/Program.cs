﻿using System;
using System.Collections.Generic;

namespace StringSorter
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> strings = new List<string>();
            Console.WriteLine("Enter strings (type 'done' to finish):");

            while (true)
            {
                string input = Console.ReadLine();

                if (input.ToLower() == "done")
                {
                    break;
                }

                strings.Add(input);
                strings.Sort(); // Sorts the list each time a new string is added

                Console.WriteLine("Current Sorted Strings:");
                foreach (string str in strings)
                {
                    Console.WriteLine(str);
                }
            }

            Console.WriteLine("Final Sorted Strings:");
            foreach (string str in strings)
            {
                Console.WriteLine(str);
            }
        }
    }
}
