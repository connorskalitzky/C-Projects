﻿using System;
using System.Data.SqlClient;

namespace FPCSCI234.DAL
{
    public class DatabaseConnection
    {
        private readonly string _connectionString;

        public DatabaseConnection()
        {
            // SQL Server connection details
            _connectionString = "Server=localhost;Port=1433;Database=master;User Id=sa;Password=YourStrong!Passw0rd;";
        }

        public SqlConnection GetConnection()
        {
            try
            {
                var connection = new SqlConnection(_connectionString);
                connection.Open();
                return connection;
            }
            catch (SqlException ex)
            {
                // Log and handle the exception as needed
                throw new Exception("An error occurred while connecting to the database.", ex);
            }
        }
    }
}
