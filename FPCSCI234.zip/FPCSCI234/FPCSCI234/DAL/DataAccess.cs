﻿using System;
using System.Data.SqlClient;
using System.Data;

namespace FPCSCI234.DAL
{
    public class DataAccess
    {
        private readonly DatabaseConnection _dbConnection;

        public DataAccess()
        {
            _dbConnection = new DatabaseConnection();
        }

        public void AddRecord(string itemName, string itemDescription, decimal itemPrice, int stockCount, int categoryId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("INSERT INTO MST_MainData (ItemName, ItemDescription, ItemPrice, StockCount, CategoryID, ADD_DTM, STAT_CD) VALUES (@ItemName, @ItemDescription, @ItemPrice, @StockCount, @CategoryID, GETDATE(), 'A')", connection);
                command.Parameters.AddWithValue("@ItemName", itemName);
                command.Parameters.AddWithValue("@ItemDescription", itemDescription);
                command.Parameters.AddWithValue("@ItemPrice", itemPrice);
                command.Parameters.AddWithValue("@StockCount", stockCount);
                command.Parameters.AddWithValue("@CategoryID", categoryId);

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    // Log and handle the exception as needed
                    throw new Exception("An error occurred while adding a record.", ex);
                }
            }
        }
        public void UpdateRecord(int itemId, string itemName, string itemDescription, decimal itemPrice, int stockCount, int categoryId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("UPDATE MST_MainData SET ItemName = @ItemName, ItemDescription = @ItemDescription, ItemPrice = @ItemPrice, StockCount = @StockCount, CategoryID = @CategoryID WHERE ItemID = @ItemID AND STAT_CD != 'D'", connection);
                command.Parameters.AddWithValue("@ItemID", itemId);
                command.Parameters.AddWithValue("@ItemName", itemName);
                command.Parameters.AddWithValue("@ItemDescription", itemDescription);
                command.Parameters.AddWithValue("@ItemPrice", itemPrice);
                command.Parameters.AddWithValue("@StockCount", stockCount);
                command.Parameters.AddWithValue("@CategoryID", categoryId);

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    throw new Exception("An error occurred while updating the record.", ex);
                }
            }
        }

        public void DeleteRecord(int itemId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("UPDATE MST_MainData SET STAT_CD = 'D' WHERE ItemID = @ItemID", connection);
                command.Parameters.AddWithValue("@ItemID", itemId);

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    throw new Exception("An error occurred while deleting the record.", ex);
                }
            }
        }

        public void UndeleteRecord(int itemId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("UPDATE MST_MainData SET STAT_CD = 'A' WHERE ItemID = @ItemID AND STAT_CD = 'D'", connection);
                command.Parameters.AddWithValue("@ItemID", itemId);

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    throw new Exception("An error occurred while undeleting the record.", ex);
                }
            }
        }

        public void PurgeRecord(int itemId)
        {
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("DELETE FROM MST_MainData WHERE ItemID = @ItemID AND STAT_CD = 'D'", connection);
                command.Parameters.AddWithValue("@ItemID", itemId);

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    throw new Exception("An error occurred while purging the record.", ex);
                }
            }
        }

        public DataTable SearchRecords(string searchTerm)
        {
            DataTable dataTable = new DataTable();
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM MST_MainData WHERE (ItemName LIKE @SearchTerm OR ItemDescription LIKE @SearchTerm) AND STAT_CD != 'D'", connection);
                command.Parameters.AddWithValue("@SearchTerm", "%" + searchTerm + "%");

                using (var adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dataTable);
                }
            }
            return dataTable;
        }

        // Method to View All Active Records
        public DataTable ViewAllRecords()
        {
            DataTable dataTable = new DataTable();
            using (var connection = _dbConnection.GetConnection())
            {
                var command = new SqlCommand("SELECT * FROM MST_MainData WHERE STAT_CD != 'D'", connection);

                using (var adapter = new SqlDataAdapter(command))
                {
                    adapter.Fill(dataTable);
                }
            }
            return dataTable;
        }

        // Additional methods as needed...
    }
}
        // Implement similar methods for Modification, Deletion, Un-deletion, Purging, Searching, and Viewing
        // ...
   
