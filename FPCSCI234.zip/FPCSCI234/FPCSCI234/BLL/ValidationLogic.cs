﻿using System;

namespace FPCSCI234.BLL
{
    public static class ValidationLogic
    {
        public static void ValidateItemDetails(string itemName, decimal itemPrice, int stockCount, int categoryId)
        {
            if (string.IsNullOrEmpty(itemName))
                throw new ArgumentException("Item name cannot be empty.");
            if (itemPrice <= 0)
                throw new ArgumentException("Item price must be greater than 0.");
            if (stockCount < 0)
                throw new ArgumentException("Stock count cannot be negative.");
            if (categoryId <= 0)
                throw new ArgumentException("Invalid category ID.");
        }

        public static void ValidateItemId(int itemId)
        {
            if (itemId <= 0)
                throw new ArgumentException("Invalid Item ID.");
        }

        // Additional validation methods for other inputs as required
        // ...
    }
}
