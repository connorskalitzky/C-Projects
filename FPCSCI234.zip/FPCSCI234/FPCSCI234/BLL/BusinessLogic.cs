﻿using System;
using FPCSCI234.DAL;
using System.Data;

namespace FPCSCI234.BLL
{
    public class BusinessLogic
    {
        private readonly DataAccess _dataAccess;

        public BusinessLogic()
        {
            _dataAccess = new DataAccess();
        }

        public void AddRecord(string itemName, string itemDescription, decimal itemPrice, int stockCount, int categoryId)
        {
            ValidationLogic.ValidateItemDetails(itemName, itemPrice, stockCount, categoryId);
            _dataAccess.AddRecord(itemName, itemDescription, itemPrice, stockCount, categoryId);
        }

        // Assuming the following methods are defined in DataAccess:
        public void UpdateRecord(int itemId, string itemName, string itemDescription, decimal itemPrice, int stockCount, int categoryId)
        {
            ValidationLogic.ValidateItemId(itemId);
            ValidationLogic.ValidateItemDetails(itemName, itemPrice, stockCount, categoryId);
            _dataAccess.UpdateRecord(itemId, itemName, itemDescription, itemPrice, stockCount, categoryId);
        }

        public void DeleteRecord(int itemId)
        {
            ValidationLogic.ValidateItemId(itemId);
            _dataAccess.DeleteRecord(itemId);
        }

        public void UndeleteRecord(int itemId)
        {
            ValidationLogic.ValidateItemId(itemId);
            _dataAccess.UndeleteRecord(itemId);
        }

        public void PurgeRecord(int itemId)
        {
            ValidationLogic.ValidateItemId(itemId);
            _dataAccess.PurgeRecord(itemId);
        }

        public DataTable SearchRecords(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                throw new ArgumentException("Search term cannot be empty.");
            return _dataAccess.SearchRecords(searchTerm);
        }

        public DataTable ViewAllRecords()
        {
            return _dataAccess.ViewAllRecords();
        }
    }
}
