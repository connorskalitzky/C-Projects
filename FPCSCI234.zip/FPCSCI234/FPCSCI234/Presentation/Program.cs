﻿using FPCSCI234.Presentation;

namespace FPCSCI234
{
    class Program
    {
        static void Main(string[] args)
        {
            UserInterface ui = new UserInterface();
            ui.DisplayMainMenu();
        }
    }
}
