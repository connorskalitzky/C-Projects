﻿using System;
using FPCSCI234.BLL;
using System.Data;

namespace FPCSCI234.Presentation
{
    public class UserInterface
    {
        private readonly BusinessLogic _businessLogic;
        private readonly MenuSystem _menuSystem;

        public UserInterface()
        {
            _businessLogic = new BusinessLogic();
            _menuSystem = new MenuSystem();
        }

        public void DisplayMainMenu()
        {
            bool exit = false;
            while (!exit)
            {
                _menuSystem.DisplayMainMenu();
                string choice = _menuSystem.GetMenuChoice();

                switch (choice)
                {
                    case "1":
                        AddItem();
                        break;
                    case "2":
                        UpdateItem();
                        break;
                    // Implement other cases for delete, undelete, purge, search, view, etc.
                    case "0":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        private void AddItem()
        {
            string itemName = ReadInput("Enter Item Name:");
            string itemDescription = ReadInput("Enter Item Description:");
            decimal itemPrice = ReadDecimalInput("Enter Item Price:");
            int stockCount = ReadIntInput("Enter Stock Count:");
            int categoryId = ReadIntInput("Enter Category ID:");

            _businessLogic.AddRecord(itemName, itemDescription, itemPrice, stockCount, categoryId);
            Console.WriteLine("Item added successfully.");
        }

        private void UpdateItem()
        {
            int itemId = ReadIntInput("Enter Item ID to Update:");
            string itemName = ReadInput("Enter New Item Name:");
            string itemDescription = ReadInput("Enter Item Description:");
            decimal itemPrice = ReadDecimalInput("Enter Item Price:");
            int stockCount = ReadIntInput("Enter Stock Count:");
            int categoryId = ReadIntInput("Enter Category ID:");

            _businessLogic.UpdateRecord(itemId, itemName, itemDescription, itemPrice, stockCount, categoryId);
            Console.WriteLine("Item updated successfully.");
        }

        private void DeleteItem()
        {
            Console.WriteLine("Enter Item ID to Delete:");
            int itemId = int.Parse(Console.ReadLine());

            _businessLogic.DeleteRecord(itemId);
            Console.WriteLine("Item deleted successfully.");
        }

        private void UndeleteItem()
        {
            Console.WriteLine("Enter Item ID to Undelete:");
            int itemId = int.Parse(Console.ReadLine());

            _businessLogic.UndeleteRecord(itemId);
            Console.WriteLine("Item undeleted successfully.");
        }

        private void PurgeItem()
        {
            Console.WriteLine("Enter Item ID to Purge:");
            int itemId = int.Parse(Console.ReadLine());

            _businessLogic.PurgeRecord(itemId);
            Console.WriteLine("Item purged successfully.");
        }

        private void SearchItems()
        {
            Console.WriteLine("Enter search term:");
            string searchTerm = Console.ReadLine();

            DataTable results = _businessLogic.SearchRecords(searchTerm);
            DisplaySearchResults(results);
        }

        private void ViewAllItems()
        {
            DataTable items = _businessLogic.ViewAllRecords();
            DisplaySearchResults(items);
        }

        private string ReadInput(string prompt)
        {
            Console.WriteLine(prompt);
            return Console.ReadLine() ?? string.Empty;
        }

        private int ReadIntInput(string prompt)
        {
            Console.WriteLine(prompt);
            string input = Console.ReadLine();
            if (int.TryParse(input, out int result))
            {
                return result;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
                return 0;
            }
        }

        private decimal ReadDecimalInput(string prompt)
        {
            Console.WriteLine(prompt);
            string input = Console.ReadLine();
            if (decimal.TryParse(input, out decimal result))
            {
                return result;
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid decimal number.");
                return 0m;
            }
        }
        private void DisplaySearchResults(DataTable results)
        {
            foreach (DataRow row in results.Rows)
            {
                Console.WriteLine($"Item ID: {row["ItemID"]}, Name: {row["ItemName"]}, Description: {row["ItemDescription"]}");
            }
        }
    }
}