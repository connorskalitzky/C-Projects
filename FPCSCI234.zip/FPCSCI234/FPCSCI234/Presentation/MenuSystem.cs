﻿using System;

namespace FPCSCI234.Presentation
{
    public class MenuSystem
    {
        public void DisplayMainMenu()
        {
            Console.WriteLine("Welcome to the Inventory Management System");
            Console.WriteLine("1. Add Item");
            Console.WriteLine("2. Update Item");
            // ... other menu options
            Console.WriteLine("0. Exit");
        }

        public string GetMenuChoice()
        {
            Console.WriteLine("Enter your choice: ");
            return Console.ReadLine() ?? string.Empty;  // Handling potential null reference
        }
    }
}
