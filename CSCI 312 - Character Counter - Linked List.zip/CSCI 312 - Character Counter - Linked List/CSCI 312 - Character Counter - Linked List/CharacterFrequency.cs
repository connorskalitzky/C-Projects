﻿public class CharacterFrequency
{
    private char _character;
    private int _frequency;

    public char Character
    {
        get { return _character; }
        set { _character = value; }
    }

    public int Frequency
    {
        get { return _frequency; }
        set { _frequency = value; }
    }

    public void Increment()
    {
        _frequency++;
    }

    public override bool Equals(object? obj) // Fixed CS8765 by marking obj as nullable
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }

        return _character == ((CharacterFrequency)obj)._character;
    }

    public override int GetHashCode() // Fixed CS0659 by overriding GetHashCode
    {
        return _character.GetHashCode();
    }

    public override string ToString()
    {
        return $"{_character}({_character.GetHashCode()}) = {_frequency}";
    }
}


