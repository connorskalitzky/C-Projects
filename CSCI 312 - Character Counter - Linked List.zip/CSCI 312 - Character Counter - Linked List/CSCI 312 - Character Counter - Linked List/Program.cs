﻿using System;
namespace CSCI_312___Character_Counter___Linked_List
{
	public class Program
	{
		public Program()
		{
		}
	}
}
public class Program
{
    public static void Main(string[] args)
    {
        if (args.Length != 2)
        {
            Console.WriteLine("Usage: programname.exe <inFile> <outFile>");
            return;
        }

        string inFile = args[0];
        string outFile = args[1];

        LinkedList<CharacterFrequency> frequencies = new LinkedList<CharacterFrequency>();

        using (StreamReader reader = new StreamReader(inFile))
        {
            int ch;
            while ((ch = reader.Read()) != -1) // Read character by character
            {
                char character = (char)ch;
                var node = frequencies.First;

                // Find if the character is already in the list
                while (node != null && node.Value.Character != character)
                {
                    node = node.Next;
                }

                if (node != null)
                {
                    // If the character is already in the list, increment the frequency
                    node.Value.Increment();
                }
                else
                {
                    // If the character is not in the list, add it
                    frequencies.AddLast(new CharacterFrequency
                    {
                        Character = character,
                        Frequency = 1
                    });
                }
            }
        }

        using (StreamWriter writer = new StreamWriter(outFile))
        {
            foreach (var frequency in frequencies)
            {
                writer.WriteLine(frequency.ToString());
            }
        }
    }
}



