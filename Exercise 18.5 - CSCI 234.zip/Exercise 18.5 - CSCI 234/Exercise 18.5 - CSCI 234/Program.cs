﻿class Program
{
    static void Main(string[] args)
    {
        // Initialize an array with sample data
        int[] arr = { 34, 19, 42, -9, 2018, 0, 2005, 77, 2099 };

        Console.WriteLine("Original array:");
        BubbleSort.PrintArray(arr);

        // Sorting the array
        BubbleSort.SortArray(arr);

        Console.WriteLine("Sorted array:");
        BubbleSort.PrintArray(arr);
    }
}
