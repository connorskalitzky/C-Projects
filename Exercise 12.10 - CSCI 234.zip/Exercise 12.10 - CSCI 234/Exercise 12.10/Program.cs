﻿using System;

namespace ShapeHierarchy
{
    abstract class Shape
    {
        public abstract string Description { get; }
    }

    abstract class TwoDimensionalShape : Shape
    {
        public abstract double Area { get; }
    }

    abstract class ThreeDimensionalShape : Shape
    {
        public abstract double Area { get; }
        public abstract double Volume { get; }
    }

    class Circle : TwoDimensionalShape
    {
        public double Radius { get; }

        public Circle(double radius) => Radius = radius;

        public override double Area => Math.PI * Radius * Radius;

        public override string Description => "A Circle with radius " + Radius;
    }

    class Square : TwoDimensionalShape
    {
        public double Side { get; }

        public Square(double side) => Side = side;

        public override double Area => Side * Side;

        public override string Description => "A Square with side " + Side;
    }

    class Sphere : ThreeDimensionalShape
    {
        public double Radius { get; }

        public Sphere(double radius) => Radius = radius;

        public override double Area => 4 * Math.PI * Radius * Radius;

        public override double Volume => (4 / 3.0) * Math.PI * Math.Pow(Radius, 3);

        public override string Description => "A Sphere with radius " + Radius;
    }

    class Cube : ThreeDimensionalShape
    {
        public double Side { get; }

        public Cube(double side) => Side = side;

        public override double Area => 6 * Side * Side;

        public override double Volume => Math.Pow(Side, 3);

        public override string Description => "A Cube with side " + Side;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Shape[] shapes = {
                new Circle(10),
                new Square(5),
                new Sphere(7),
                new Cube(4)
            };

            foreach (var shape in shapes)
            {
                Console.WriteLine(shape.Description);
                switch (shape)
                {
                    case TwoDimensionalShape twoDShape:
                        Console.WriteLine("Area: " + twoDShape.Area);
                        break;
                    case ThreeDimensionalShape threeDShape:
                        Console.WriteLine("Area: " + threeDShape.Area + ", Volume: " + threeDShape.Volume);
                        break;
                }
                Console.WriteLine();
            }
        }
    }
}
