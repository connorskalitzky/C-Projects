﻿using System;
using System.Diagnostics;

class Program
{
    static void Main(string[] args)
    {
        int[] sizes = { 100, 1000, 10000, 25000, 50000, 100000, 250000, 500000, 750000, 1000000 };
        Random rand = new Random();

        foreach (int size in sizes)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                array[i] = rand.Next(1, 101);
            }

            Stopwatch stopwatch = Stopwatch.StartNew();
            Array.Sort(array);
            stopwatch.Stop();

            Console.WriteLine($"Array.Sort: Size = {size}, Duration = {stopwatch.ElapsedMilliseconds} ms");
        }
    }
}
