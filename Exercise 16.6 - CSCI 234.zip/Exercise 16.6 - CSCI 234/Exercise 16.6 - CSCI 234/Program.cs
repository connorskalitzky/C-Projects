﻿using System;

namespace ThreeLetterCombinations
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a five-letter word: ");
            string inputWord = Console.ReadLine();

            if (inputWord.Length != 5)
            {
                Console.WriteLine("Input must be a five-letter word.");
                return;
            }

            GenerateThreeLetterCombinations(inputWord);
        }

        static void GenerateThreeLetterCombinations(string word)
        {
            for (int i = 0; i < word.Length; i++)
            {
                for (int j = 0; j < word.Length; j++)
                {
                    if (j == i) continue;  // Ensure the second character is different from the first

                    for (int k = 0; k < word.Length; k++)
                    {
                        if (k == i || k == j) continue;  // Ensure the third character is different from the first and second

                        Console.WriteLine($"{word[i]}{word[j]}{word[k]}");
                    }
                }
            }
        }
    }
}
