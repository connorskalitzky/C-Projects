﻿using System;

namespace DateTest
{
    public class Date
    {
        // Auto-implemented properties for Month, Day, and Year
        public int Month { get; set; }
        public int Day { get; set; }
        public int Year { get; set; }

        // Constructor that initializes the properties
        public Date(int month, int day, int year)
        {
            Month = month;
            Day = day;
            Year = year;
        }

        // Method to display the date
        public void DisplayDate()
        {
            Console.WriteLine($"{Month}/{Day}/{Year}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Create a Date object
            Date myDate = new Date(9, 11, 2023);

            // Display the date
            Console.WriteLine("The date is:");
            myDate.DisplayDate();
        }
    }
}
