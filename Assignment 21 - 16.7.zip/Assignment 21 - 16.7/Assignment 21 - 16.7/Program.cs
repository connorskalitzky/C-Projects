﻿using System;
using System.Text.RegularExpressions;

namespace FirstLetterUppercase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a string:");
            string input = Console.ReadLine();

            string output = ConvertFirstLetterToUpperCase(input);
            Console.WriteLine("Output string:");
            Console.WriteLine(output);
        }

        // Method to convert the first letter of each word to uppercase using regular expressions
        static string ConvertFirstLetterToUpperCase(string input)
        {
            // The regex pattern @"\b\w" matches the first letter of each word
            // The Replace method replaces each matched character with its uppercase counterpart
            return Regex.Replace(input, @"\b\w", match => match.Value.ToUpper());
        }
    }
}
