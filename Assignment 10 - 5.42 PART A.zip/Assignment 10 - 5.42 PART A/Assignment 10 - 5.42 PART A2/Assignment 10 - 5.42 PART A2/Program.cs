﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter an encrypted four-digit integer: ");
        int encryptedNumber = int.Parse(Console.ReadLine());

        int digit1 = (encryptedNumber / 10) % 10;
        int digit2 = encryptedNumber % 10;
        int digit3 = (encryptedNumber / 1000 + 3) % 10;
        int digit4 = ((encryptedNumber / 100) % 10 + 3) % 10;

        int originalNumber = digit3 * 1000 + digit4 * 100 + digit1 * 10 + digit2;

        Console.WriteLine("Original number: " + originalNumber.ToString("D4"));
    }
}