﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter a four-digit integer: ");
        int number = int.Parse(Console.ReadLine());

        int digit1 = (number / 1000 + 7) % 10;
        int digit2 = ((number / 100) % 10 + 7) % 10;
        int digit3 = ((number / 10) % 10 + 7) % 10;
        int digit4 = (number % 10 + 7) % 10;

        int encryptedNumber = digit3 * 1000 + digit4 * 100 + digit1 * 10 + digit2;

        Console.WriteLine("Encrypted number: " + encryptedNumber);
    }
}