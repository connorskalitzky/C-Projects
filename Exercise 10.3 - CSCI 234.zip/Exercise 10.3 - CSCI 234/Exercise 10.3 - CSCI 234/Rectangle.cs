﻿using System;

namespace RectangleApp
{
    public class Rectangle
    {
        private float _length;
        private float _width;

        public Rectangle()
        {
            _length = 1;
            _width = 1;
        }

        public float Length
        {
            get => _length;
            set
            {
                if (value > 0.0f && value < 20.0f)
                {
                    _length = value;
                }
                else
                {
                    throw new ArgumentException("Length must be greater than 0.0 and less than 20.0");
                }
            }
        }

        public float Width
        {
            get => _width;
            set
            {
                if (value > 0.0f && value < 20.0f)
                {
                    _width = value;
                }
                else
                {
                    throw new ArgumentException("Width must be greater than 0.0 and less than 20.0");
                }
            }
        }

        public float Perimeter => 2 * (_length + _width);

        public float Area => _length * _width;
    }
}

