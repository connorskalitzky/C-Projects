﻿using System;

namespace RectangleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rect = new Rectangle();

            Console.WriteLine($"Initial length: {rect.Length}");
            Console.WriteLine($"Initial width: {rect.Width}");
            Console.WriteLine($"Initial perimeter: {rect.Perimeter}");
            Console.WriteLine($"Initial area: {rect.Area}");

            try
            {
                Console.WriteLine("Setting length to 10...");
                rect.Length = 10;

                Console.WriteLine("Setting width to 5...");
                rect.Width = 5;

                Console.WriteLine($"Updated length: {rect.Length}");
                Console.WriteLine($"Updated width: {rect.Width}");
                Console.WriteLine($"Updated perimeter: {rect.Perimeter}");
                Console.WriteLine($"Updated area: {rect.Area}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
