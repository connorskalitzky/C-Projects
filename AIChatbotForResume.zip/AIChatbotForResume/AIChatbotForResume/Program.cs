﻿using System;
using System.Text.RegularExpressions;
using System.IO;

namespace AIChatbotForResume
{
    class Program
    {
        static string userName = "there"; // Default username, can be personalized

        static void Main(string[] args)
        {
            Console.WriteLine("Hello! I'm an AI chatbot. What's your name?");
            Console.Write("You: ");
            userName = Console.ReadLine();

            Console.WriteLine($"Nice to meet you, {userName}! Ask me about my creator's professional profile or type 'help' to see what I can do.");

            while (true)
            {
                Console.Write($"{userName}: ");
                var userInput = Console.ReadLine();

                LogConversation($"{userName}: {userInput}"); // Log user input

                if (userInput.ToLowerInvariant() == "help")
                {
                    Console.WriteLine(Help());
                    continue;
                }

                var response = GetResponse(userInput);
                Console.WriteLine("Chatbot: " + response);
                LogConversation("Chatbot: " + response); // Log chatbot response
            }
        }

        static string GetResponse(string userInput)
        {
            userInput = userInput.ToLowerInvariant();

            if (userInput.Contains("skills"))
            {
                return GetSkills();
            }
            if (Regex.IsMatch(userInput, @"(education|degree|university|college)"))
            {
                return GetEducation();
            }
            if (Regex.IsMatch(userInput, @"(experience|job|work|employment)"))
            {
                return GetWorkExperience();
            }
            if (Regex.IsMatch(userInput, @"(leadership|volunteer|community)"))
            {
                return GetVolunteeringExperience();
            }
            if (Regex.IsMatch(userInput, @"(hi|hello|hey)"))
            {
                return $"Hello {userName}! What would you like to know?";
            }

            return "I'm not sure how to answer that. Can you try asking something else?";
        }

        static string GetSkills()
        {
            return "I'm skilled in C#, JavaScript, Python, SQL, CSS, and HTML. " +
                   "I have 9 years of experience in IT, technical support, networking, and software development " +
                   "proficient in Microsoft Office Suite, Microsoft Azure, and Visual Studio. " +
                   "Additionally, I have experience with QuickBooks and accounting.";
            // Add more details from resume here
        }

        static string GetEducation()
        {
            return "I'm currently pursuing a Bachelor of Science in Computer Science at Davenport University " +
                   "with a 3.54 GPA. Previously, I previously studied at Grand Valley State University before transferring " +
                   "and I received a high school diploma from Byron Center High School with a 3.7 GPA.";
            // Add more details from resume here
        }

        static string GetWorkExperience()
        {
            return "I have worked in various technology and customer service roles, " +
                   "including as an Assistant at Direct Electronics Plus and a Store Associate at Adidas.";
            // Add more details from resume here
        }

        static string GetVolunteeringExperience()
        {
            return "I've volunteered at Byron Center High School to help start and support the lacrosse program " +
                   "and served as a Classroom Helper at Saint Sebastian Church.";
            // Add more details from resume here
        }

        static string Help()
        {
            return "Here are some things you can ask me:\n" +
                   "- Tell me about your skills\n" +
                   "- What is your educational background?\n" +
                   "- Describe your work experience\n" +
                   "- What leadership or volunteering experience do you have?\n" +
                   "- How can I contact you?";
        }

        static void LogConversation(string message)
        {
            try
            {
                // Consider including a timestamp and ensuring the file is stored in a user-writable location
                File.AppendAllText("chatlog.txt", DateTime.Now + ": " + message + Environment.NewLine);
            }
            catch (Exception ex)
            {
                // Handle exceptions from file I/O here
                Console.WriteLine("An error occurred while logging the conversation: " + ex.Message);
            }
        }
    }
}

