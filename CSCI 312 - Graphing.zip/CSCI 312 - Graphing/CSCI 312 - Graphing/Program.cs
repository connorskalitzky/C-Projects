﻿using System;

namespace GraphDataStructure
{
    class Program
    {
        static void Main(string[] args)
        {
            Graph<int> g = new Graph<int>();

            // Adding nodes
            for (int i = 0; i < 5; i++)
            {
                g.AddNode(i);
            }

            // Adding edges
            g.AddEdge(g[0], g[1]);
            g.AddEdge(g[0], g[4]);
            g.AddEdge(g[1], g[3]);
            g.AddEdge(g[1], g[4]);
            g.AddEdge(g[2], g[1]);
            g.AddEdge(g[3], g[2]);
            g.AddEdge(g[3], g[4]);

            Console.WriteLine("Breadth First Search starting from node 0:");
            g.BreadthFirstSearch(g[0]);
        }
    }
}
