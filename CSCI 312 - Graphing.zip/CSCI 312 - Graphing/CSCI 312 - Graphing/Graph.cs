﻿using System;
using System.Collections.Generic;

namespace GraphDataStructure
{
    public class Graph<T>
    {
        private List<GraphNode<T>> _nodes;

        public Graph()
        {
            _nodes = new List<GraphNode<T>>();
        }

        public void AddNode(T data)
        {
            GraphNode<T> newNode = new GraphNode<T>(data);
            _nodes.Add(newNode);
        }

        public void AddEdge(GraphNode<T> node1, GraphNode<T> node2)
        {
            if (!_nodes.Contains(node1) || !_nodes.Contains(node2))
            {
                throw new ArgumentException("Both nodes should be part of the graph.");
            }

            node1.AddAdjacentNode(node2);
            node2.AddAdjacentNode(node1);
        }

        // Add indexer to access nodes by index
        public GraphNode<T> this[int index]
        {
            get
            {
                if (index < 0 || index >= _nodes.Count)
                {
                    throw new IndexOutOfRangeException("Index out of range.");
                }
                return _nodes[index];
            }
        }

        public void BreadthFirstSearch(GraphNode<T> startingNode)
        {
            Queue<GraphNode<T>> queue = new Queue<GraphNode<T>>();
            HashSet<GraphNode<T>> visitedNodes = new HashSet<GraphNode<T>>();

            queue.Enqueue(startingNode);
            visitedNodes.Add(startingNode);

            while (queue.Count > 0)
            {
                GraphNode<T> current = queue.Dequeue();
                Console.Write(current.Data + " ");

                foreach (GraphNode<T> adjacentNode in current.GetAdjacentNodes())
                {
                    if (!visitedNodes.Contains(adjacentNode))
                    {
                        queue.Enqueue(adjacentNode);
                        visitedNodes.Add(adjacentNode);
                    }
                }
            }

            Console.WriteLine();
        }
    }
}
