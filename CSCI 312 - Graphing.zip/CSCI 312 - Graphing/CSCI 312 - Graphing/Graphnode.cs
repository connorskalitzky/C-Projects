﻿using System;
using System.Collections.Generic;

namespace GraphDataStructure
{
    public class GraphNode<T>
    {
        private T _data;
        private List<GraphNode<T>> _adjacentNodes;

        public GraphNode(T data)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data), "Data cannot be null.");
            _adjacentNodes = new List<GraphNode<T>>();
        }

        public T Data
        {
            get { return _data; }
            set { _data = value; }
        }

        public void AddAdjacentNode(GraphNode<T> node)
        {
            _adjacentNodes.Add(node);
        }

        public List<GraphNode<T>> GetAdjacentNodes()
        {
            return _adjacentNodes;
        }
    }
}
