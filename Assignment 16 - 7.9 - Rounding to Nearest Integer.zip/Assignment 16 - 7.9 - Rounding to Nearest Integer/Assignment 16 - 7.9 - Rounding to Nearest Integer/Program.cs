﻿using System;

namespace RoundingNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of values you want to round:");
            int numberOfValues = int.Parse(Console.ReadLine());

            for (int i = 1; i <= numberOfValues; i++)
            {
                Console.WriteLine($"Enter value {i}:");
                double originalValue = double.Parse(Console.ReadLine());

                double roundedValue = Math.Floor(originalValue + 0.5);
                Console.WriteLine($"Original value: {originalValue}, Rounded value: {roundedValue}");
            }

            Console.WriteLine("All values have been processed.");
        }
    }
}
