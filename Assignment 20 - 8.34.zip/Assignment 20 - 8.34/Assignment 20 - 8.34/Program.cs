﻿using System;

class SocialConsciousnessPoll
{
    static void Main()
    {
        string[] topics = {
            "Climate Change",
            "Education",
            "Healthcare",
            "Income Inequality",
            "Privacy Rights"
        };

        int[,] responses = new int[5, 10];

        while (true)
        {
            Console.WriteLine("Rate the following issues from 1 (least important) to 10 (most important):");
            for (int i = 0; i < topics.Length; i++)
            {
                Console.Write($"{topics[i]}: ");
                int rating = int.Parse(Console.ReadLine());

                if (rating >= 1 && rating <= 10)
                {
                    responses[i, rating - 1]++;
                }
                else
                {
                    Console.WriteLine("Invalid rating. Please enter a number between 1 and 10.");
                    i--;
                }
            }

            Console.Write("Enter 'y' to continue or any other key to exit and show the results: ");
            char input = char.Parse(Console.ReadLine());

            if (input != 'y' && input != 'Y')
            {
                break;
            }
        }

        Console.WriteLine("\nSummary of the results:");

        Console.Write("Issue".PadRight(20));
        for (int i = 1; i <= 10; i++)
        {
            Console.Write($" {i}".PadRight(4));
        }
        Console.WriteLine(" Average");

        int highestTotal = int.MinValue;
        int lowestTotal = int.MaxValue;
        string highestIssue = "";
        string lowestIssue = "";

        for (int i = 0; i < topics.Length; i++)
        {
            Console.Write(topics[i].PadRight(20));
            int totalPoints = 0;
            int totalRatings = 0;

            for (int j = 0; j < 10; j++)
            {
                Console.Write($" {responses[i, j]}".PadRight(4));
                totalPoints += responses[i, j] * (j + 1);
                totalRatings += responses[i, j];
            }

            double average = (double)totalPoints / totalRatings;
            Console.WriteLine($" {average,6:N1}");

            if (totalPoints > highestTotal)
            {
                highestTotal = totalPoints;
                highestIssue = topics[i];
            }

            if (totalPoints < lowestTotal)
            {
                lowestTotal = totalPoints;
                lowestIssue = topics[i];
            }
        }

        Console.WriteLine($"\nIssue with the highest point total: {highestIssue} ({highestTotal} points)");
        Console.WriteLine($"Issue with the lowest point total: {lowestIssue} ({lowestTotal} points)");
    }
}
