﻿using System;
using System.IO;
using System.Collections.Generic;

public class CharacterFrequency
{
    public char Character { get; set; }
    public int Frequency { get; set; }

    public CharacterFrequency(char character)
    {
        Character = character;
        Frequency = 1;
    }

    public void Increment()
    {
        Frequency++;
    }

    public override bool Equals(object obj)
    {
        if (obj is CharacterFrequency other)
        {
            return Character == other.Character;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return Character.GetHashCode();
    }

    public override string ToString()
    {
        return $"{Character}({(int)Character})\t{Frequency}";
    }
}

public class Program
{
    public static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: programname.exe <inFile> <outFile>");
            return;
        }

        string inFile = args[0];
        string outFile = args[1];

        List<CharacterFrequency> frequencies = new List<CharacterFrequency>();

        using (FileStream fs = File.OpenRead(inFile))
        {
            int b;
            while ((b = fs.ReadByte()) != -1)
            {
                char ch = (char)b;
                CharacterFrequency cf = new CharacterFrequency(ch);
                int index = frequencies.IndexOf(cf);
                if (index >= 0)
                {
                    frequencies[index].Increment();
                }
                else
                {
                    frequencies.Add(cf);
                }
            }
        }

        using (StreamWriter sw = new StreamWriter(outFile))
        {
            foreach (CharacterFrequency cf in frequencies)
            {
                sw.WriteLine(cf.ToString());
            }
        }
    }
}
