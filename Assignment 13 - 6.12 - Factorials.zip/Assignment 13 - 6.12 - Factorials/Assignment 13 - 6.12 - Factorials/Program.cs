﻿using System;

namespace FactorialsTable
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Factorials Table");
            Console.WriteLine("----------------");

            for (int i = 1; i <= 5; i++)
            {
                int factorial = 1;
                for (int j = 1; j <= i; j++)
                {
                    factorial *= j;
                }
                Console.WriteLine("{0}! = {1}", i, factorial);
            }
        }
    }
}