﻿using System;
using System.Collections.Generic;
using System.IO;
using CSCI_312___Final_Project;
using System.Xml.Linq;

class HuffmanCoding
{
    static void Main(string[] args)
    {
        if (args[0] == "compress")
        {
            string inputFilePath = args[1];
            string outputFilePath = args[2];

            Dictionary<char, int> characterFrequencies = CalculateCharacterFrequencies(inputFilePath);
            SortedSet<HuffmanNode> priorityQueue = BuildPriorityQueue(characterFrequencies);
            HuffmanNode? root = BuildHuffmanTree(priorityQueue);
            Dictionary<char, string> huffmanCodes = new Dictionary<char, string>();
            if (root != null)
            {
                GenerateHuffmanCodes(root, "", huffmanCodes);
                CompressFile(inputFilePath, outputFilePath, characterFrequencies, huffmanCodes);
            }
        }
        else if (args[0] == "decompress")
        {
            string inputFilePath = args[1];
            string outputFilePath = args[2];

            DecompressFile(inputFilePath, outputFilePath);
        }
    }

    static Dictionary<char, int> CalculateCharacterFrequencies(string filePath)
    {
        Dictionary<char, int> characterFrequencies = new Dictionary<char, int>();

        using (StreamReader sr = new StreamReader(filePath))
        {
            int c;
            while ((c = sr.Read()) != -1)
            {
                char character = (char)c;
                if (characterFrequencies.ContainsKey(character))
                {
                    characterFrequencies[character]++;
                }
                else
                {
                    characterFrequencies.Add(character, 1);
                }
            }
        }

        return characterFrequencies;
    }

    static SortedSet<HuffmanNode> BuildPriorityQueue(Dictionary<char, int> characterFrequencies)
    {
        SortedSet<HuffmanNode> priorityQueue = new SortedSet<HuffmanNode>();

        foreach (KeyValuePair<char, int> entry in characterFrequencies)
        {
            HuffmanNode node = new HuffmanNode(entry.Key, entry.Value);
            priorityQueue.Add(node);
        }

        return priorityQueue;
    }

    static HuffmanNode? BuildHuffmanTree(SortedSet<HuffmanNode> priorityQueue)
    {
        while (priorityQueue.Count > 1)
        {
            HuffmanNode? left = priorityQueue.Min;
            if (left != null)
            {
                priorityQueue.Remove(left);
            }

            HuffmanNode? right = priorityQueue.Min;
            if (right != null)
            {
                priorityQueue.Remove(right);
            }

            if (left != null && right != null)
            {
                HuffmanNode parent = new HuffmanNode('\0', left.Frequency + right.Frequency)
                {
                    Left = left,
                    Right = right
                };

                priorityQueue.Add(parent);
            }
        }

        return priorityQueue.Min;
    }

    static void GenerateHuffmanCodes(HuffmanNode node, string code, Dictionary<char, string> huffmanCodes)
    {
        if (node == null)
            return;

        if (node.Left == null && node.Right == null)
        {
            huffmanCodes[node.Character] = code;
        }

        GenerateHuffmanCodes(node.Left!, code + "0", huffmanCodes);
        GenerateHuffmanCodes(node.Right!, code + "1", huffmanCodes);
    }

    static void CompressFile(string inputFilePath, string outputFilePath, Dictionary<char, int> characterFrequencies, Dictionary<char, string> huffmanCodes)
    {
        using (StreamReader sr = new StreamReader(inputFilePath))
        using (BinaryWriter bw = new BinaryWriter(File.Open(outputFilePath, FileMode.Create)))
        {
            bw.Write(characterFrequencies.Count);
            foreach (KeyValuePair<char, int> entry in characterFrequencies)
            {
                bw.Write(entry.Key);
                bw.Write(entry.Value);
            }

            int c;
            int bitsInBuffer = 0;
            byte buffer = 0;

            while ((c = sr.Read()) != -1)
            {
                char character = (char)c;
                string huffmanCode = huffmanCodes[character];

                foreach (char bit in huffmanCode)
                {
                    buffer = (byte)((buffer << 1) | (bit == '1' ? 1 : 0));
                    bitsInBuffer++;

                    if (bitsInBuffer == 8)
                    {
                        bw.Write(buffer);
                        bitsInBuffer = 0;
                        buffer = 0;
                    }
                }
            }

            if (bitsInBuffer > 0)
            {
                buffer <<= (8 - bitsInBuffer);
                bw.Write(buffer);
            }
        }
    }

    static void DecompressFile(string inputFilePath, string outputFilePath)
    {
        using (BinaryReader br = new BinaryReader(File.Open(inputFilePath, FileMode.Open)))
        using (StreamWriter sw = new StreamWriter(outputFilePath))
        {
            int numEntries = br.ReadInt32();
            Dictionary<char, int> characterFrequencies = new Dictionary<char, int>();

            for (int i = 0; i < numEntries; i++)
            {
                char character = br.ReadChar();
                int frequency = br.ReadInt32();
                characterFrequencies[character] = frequency;
            }

            SortedSet<HuffmanNode> priorityQueue = BuildPriorityQueue(characterFrequencies);
            HuffmanNode? root = BuildHuffmanTree(priorityQueue);

            HuffmanNode? currentNode = root;
            byte buffer = br.ReadByte();
            int bitsInBuffer = 8;

            while (true)
            {
                while (currentNode?.Left != null && currentNode?.Right != null && bitsInBuffer > 0)
                {
                    if ((buffer & 0x80) == 0)
                        currentNode = currentNode.Left;
                    else
                        currentNode = currentNode.Right;

                    buffer <<= 1;
                    bitsInBuffer--;

                    if (bitsInBuffer == 0)
                    {
                        if (br.BaseStream.Position < br.BaseStream.Length)
                        {
                            buffer = br.ReadByte();
                            bitsInBuffer = 8;
                        }
                    }
                }

                if (currentNode?.Left == null && currentNode?.Right == null)
                {
                    if (currentNode != null)
                    {
                        sw.Write(currentNode.Character);
                    }
                    currentNode = root;
                }

                if (br.BaseStream.Position == br.BaseStream.Length && bitsInBuffer == 0)
                    break;
            }
        }
    }
}
