﻿using System;
namespace CSCI_312___Final_Project
{
    class HuffmanNode : IComparable<HuffmanNode?>
    {
        public char Character { get; set; }
        public int Frequency { get; set; }
        public HuffmanNode Left { get; set; } = null!;
        public HuffmanNode Right { get; set; } = null!;

        public HuffmanNode(char character, int frequency)
        {
            Character = character;
            Frequency = frequency;
        }

        public int CompareTo(HuffmanNode? other)
        {
            return Frequency.CompareTo(other?.Frequency);
        }
    }
}
