﻿using System;

namespace MPGCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true) // Keep running the program until the user decides to exit
            {
                try
                {
                    // Input miles driven
                    Console.Write("Enter miles driven: ");
                    double milesDriven = double.Parse(Console.ReadLine());

                    // Input gallons used
                    Console.Write("Enter gallons used: ");
                    double gallonsUsed = double.Parse(Console.ReadLine());

                    // Calculate and display MPG
                    double mpg = milesDriven / gallonsUsed;
                    Console.WriteLine($"Miles per gallon: {mpg:F2}\n");
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter numeric values.\n");
                }

                // Check if the user wants to continue or exit
                Console.WriteLine("Do you want to try again? (yes/no): ");
                string response = Console.ReadLine();
                if (response?.ToLower() != "yes")
                    break;
            }
        }
    }
}
