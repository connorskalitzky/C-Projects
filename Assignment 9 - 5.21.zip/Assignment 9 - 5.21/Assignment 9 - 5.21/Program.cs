﻿using System;

namespace LargestIntegerApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int counter = 1;
            int number;
            int largest = int.MinValue;

            Console.WriteLine("Enter 10 integers:");

            while (counter <= 10)
            {
                Console.Write($"Number {counter}: ");
                number = int.Parse(Console.ReadLine());

                if (number > largest)
                {
                    largest = number;
                }

                counter++;
            }

            Console.WriteLine($"The largest integer is {largest}.");
        }
    }
}