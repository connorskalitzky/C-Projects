﻿using System;
using System.Collections.Generic;

public class TreeNode<T> where T : IComparable<T>
{
    public T Value { get; set; }
    public TreeNode<T> Left { get; set; }
    public TreeNode<T> Right { get; set; }

    public TreeNode(T value)
    {
        Value = value;
        Left = Right = null;
    }
}

public class BinarySearchTree<T> where T : IComparable<T>
{
    public TreeNode<T> Root { get; private set; }
    private int count;

    public int Size => count;

    public void Add(T value)
    {
        if (Root == null)
        {
            Root = new TreeNode<T>(value);
            count++;
        }
        else
        {
            AddTo(Root, value);
        }
    }

    private void AddTo(TreeNode<T> node, T value)
    {
        if (value.CompareTo(node.Value) < 0)
        {
            if (node.Left == null)
            {
                node.Left = new TreeNode<T>(value);
                count++;
            }
            else
            {
                AddTo(node.Left, value);
            }
        }
        else if (value.CompareTo(node.Value) > 0)
        {
            if (node.Right == null)
            {
                node.Right = new TreeNode<T>(value);
                count++;
            }
            else
            {
                AddTo(node.Right, value);
            }
        }
    }

    public TreeNode<T> Find(T value)
    {
        return Find(value, Root);
    }

    private TreeNode<T> Find(T value, TreeNode<T> parent)
    {
        if (parent != null)
        {
            if (value.CompareTo(parent.Value) < 0)
            {
                return Find(value, parent.Left);
            }
            else if (value.CompareTo(parent.Value) > 0)
            {
                return Find(value, parent.Right);
            }
            else
            {
                return parent;
            }
        }
        return null;
    }

    public List<T> InOrder(TreeNode<T> node)
    {
        var result = new List<T>();
        if (node != null)
        {
            result.AddRange(InOrder(node.Left));
            result.Add(node.Value);
            result.AddRange(InOrder(node.Right));
        }
        return result;
    }

    public List<T> PreOrder(TreeNode<T> node)
    {
        var result = new List<T>();
        if (node != null)
        {
            result.Add(node.Value);
            result.AddRange(PreOrder(node.Left));
            result.AddRange(PreOrder(node.Right));
        }
        return result;
    }

    public List<T> PostOrder(TreeNode<T> node)
    {
        var result = new List<T>();
        if (node != null)
        {
            result.AddRange(PostOrder(node.Left));
            result.AddRange(PostOrder(node.Right));
            result.Add(node.Value);
        }
        return result;
    }
}

class Program
{
    static void Main(string[] args)
    {
        var bst = new BinarySearchTree<string>();

        bst.Add("D");
        bst.Add("B");
        bst.Add("A");
        bst.Add("C");
        bst.Add("F");
        bst.Add("E");
        bst.Add("G");

        Console.WriteLine("Size of the BST: " + bst.Size);

        Console.WriteLine("\nInorder Traversal:");
        var inOrder = bst.InOrder(bst.Root);
        foreach (var node in inOrder)
        {
            Console.Write(node + " ");
        }

        Console.WriteLine("\n\nPreorder Traversal:");

        var preOrder = bst.PreOrder(bst.Root);
        foreach (var node in preOrder)
        {
            Console.Write(node + " ");
        }

        Console.WriteLine("\n\nPostorder Traversal:");
        var postOrder = bst.PostOrder(bst.Root);
        foreach (var node in postOrder)
        {
            Console.Write(node + " ");
        }

        Console.WriteLine("\n\nFind node with value 'A': " + bst.Find("A").Value);
        Console.WriteLine("Find node with value 'Z': " + (bst.Find("Z") != null ? bst.Find("Z").Value : "null"));
    }
}
