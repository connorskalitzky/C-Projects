﻿using System;

class SalesCommission
{
    static void Main()
    {
        int[] rangeCounters = new int[9];
        int salespeopleCount;

        Console.Write("Enter the number of salespeople: ");
        salespeopleCount = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < salespeopleCount; i++)
        {
            Console.Write("Enter the gross sales for salesperson {0}: ", i + 1);
            double grossSales = Convert.ToDouble(Console.ReadLine());
            int salary = CalculateSalary(grossSales);

            if (salary >= 1000)
            {
                rangeCounters[8]++;
            }
            else
            {
                rangeCounters[(salary - 200) / 100]++;
            }
        }

        Console.WriteLine("\nSalary Range\tNumber of Salespeople");
        for (int i = 0; i < 8; i++)
        {
            Console.WriteLine("${0}-{1}\t\t{2}", i * 100 + 200, (i + 1) * 100 + 199, rangeCounters[i]);
        }
        Console.WriteLine("$1000 and over\t{0}", rangeCounters[8]);
    }

    static int CalculateSalary(double grossSales)
    {
        const int baseSalary = 200;
        const double commissionRate = 0.09;

        return baseSalary + (int)(grossSales * commissionRate);
    }
}
