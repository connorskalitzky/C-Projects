﻿using System;
namespace CSCI_312___Hashing
{
    public class Student
    {
        public int StudentId { get; set; }

        public new int GetHashCode()
        {
            return StudentId % 100;
        }
    }
}