﻿using System;
using System.Collections.Generic;
using CSCI_312___Hashing;

class Program
{
    static void Main(string[] args)
    {
        List<int> studentIds = new List<int> { 99999999, 99999999, 75000000, 50000000, 25000000, 15000, 10000, 5000, 1 };

        foreach (int id in studentIds)
        {
            Student student = new Student { StudentId = id };
            Console.WriteLine($"Student Id: {student.StudentId}, Hash: {student.GetHashCode()}");
        }
    }
}

