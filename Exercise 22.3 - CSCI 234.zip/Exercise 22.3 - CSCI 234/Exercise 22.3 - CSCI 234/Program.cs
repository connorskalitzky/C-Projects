﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;

namespace AuthorsTableAppModification
{
    public partial class BooksEntities : DbContext
    {
        public BooksEntities()
            : base("name=BooksEntities")
        {
        }

        public virtual DbSet<Author> Authors { get; set; }
    }

    // Author class
    public class Author
    {
        public int AuthorID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    // Form class
    public partial class AuthorsForm : Form
    {
        private BooksEntities dbContext;

        public AuthorsForm()
        {
            InitializeComponent();
            dbContext = new BooksEntities();
            LoadAllAuthors();
        }

        private void LoadAllAuthors()
        {
            dbContext.Authors.Load();
            authorBindingSource.DataSource = dbContext.Authors.Local;
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            string lastName = searchTextBox.Text;
            var query = from author in dbContext.Authors
                        where author.LastName.Contains(lastName)
                        select author;
            authorBindingSource.DataSource = query.ToList();
        }

        private void browseAllButton_Click(object sender, EventArgs e)
        {
            LoadAllAuthors();
        }
    }
}
