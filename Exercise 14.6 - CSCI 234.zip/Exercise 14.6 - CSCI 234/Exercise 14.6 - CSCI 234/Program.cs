﻿using System;

namespace TemperatureConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Fahrenheit temperature: ");
            string input = Console.ReadLine();

            if (double.TryParse(input, out double fahrenheit))
            {
                double celsius = (5.0 / 9.0) * (fahrenheit - 32);
                Console.WriteLine($"Temperature in Celsius: {celsius:F2} °C");
            }
            else
            {
                Console.WriteLine("Please enter a valid number for the Fahrenheit temperature.");
            }
        }
    }
}
