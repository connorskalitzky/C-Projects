﻿using System;

class ArrayManipulations
{
    static void Main()
    {
    
        int[] counts = new int[3];
        for (int i = 0; i < counts.Length; i++)
        {
            counts[i] = 0;
        }

        int[] bonus = new int[4] { 1, 2, 3, 4 };
        for (int i = 0; i < bonus.Length; i++)
        {
            bonus[i]++;
        }

        int[] bestScores = new int[5] { 98, 85, 76, 92, 100 };
        Console.WriteLine("Best Scores:");
        for (int i = 0; i < bestScores.Length; i++)
        {
            Console.WriteLine("{0}. {1}", i + 1, bestScores[i]);
        }
    }
}


